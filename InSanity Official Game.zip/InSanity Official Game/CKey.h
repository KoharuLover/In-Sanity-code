#pragma once
#include "CGameObject.h"

//NOT USABLE

class CKey : public CGameObject
{
private:



public:

	CKey(int posK) : CGameObject(posK) {}

};

