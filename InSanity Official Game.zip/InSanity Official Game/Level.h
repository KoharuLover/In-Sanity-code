#ifndef LEVEL_H
#define LEVEL_H


class Level
{
public:
    Level();
    virtual void loadLevel() = 0;
protected:

private:
};

#endif // LEVEL_H