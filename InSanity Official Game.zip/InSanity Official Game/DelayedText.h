#include <iostream>
#include <thread>  
#include <chrono>  


void printWithDelay(const std::string& text, std::chrono::milliseconds delay);

void clearScreen();

