#include "Weapon.h"

//Weapon::Weapon()
//{
//	attack = 5;
//}

int Weapon::attackUp()
{
	return attack;
}
