#pragma once
#include <stdlib.h>
#include <iostream>
class WaiZhengRNG
{
private:
	int rng;

public:
	WaiZhengRNG();
	bool flip();
};

