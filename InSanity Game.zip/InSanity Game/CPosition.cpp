#include "CPosition.h"

//FULLY FUNCTIONAL

int CPosition::getPos() const
{
    return posValue;
}

void CPosition::setPos(int posV)
{
    posValue = posV;
}
