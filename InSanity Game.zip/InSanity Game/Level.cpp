#include <iostream>
#include <stdlib.h>
#include <string>
#include "Level.h"
#include "Level1.h"
#include "Menu.h"
using namespace std;

Level::Level()
{

}