#include "CWeapon.h"

//FUNCTIONAL

int CWeapon::getWeaponATK() const
{
	return attack;
}
